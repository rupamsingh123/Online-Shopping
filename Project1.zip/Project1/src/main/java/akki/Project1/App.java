package akki.Project1;

import rup.com.modul.Product;
import rup.com.service.ProductServiceImp;


/**
 * Hello world!
 *
 */
public class App 
{
    public static void main( String[] args )
    {
    	System.out.println("project" );
    	
        ProductServiceImp pser = new ProductServiceImp();
        Product pmod= new Product();
        pser.createProduct(pmod);
        System.out.println("Record added");
        
     // Update User
        
        System.out.println("User updated successfully!");
    }
}
