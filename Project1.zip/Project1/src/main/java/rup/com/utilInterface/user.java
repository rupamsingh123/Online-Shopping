package rup.com.utilInterface;

public interface user {
	int getUserID(); // Getter method for UserID

    String getUsername(); // Getter method for Username

    String getPassword(); // Getter method for Password

    String getEmail(); // Getter method for Email

   String  getAddress(); // Getter method for Address

}
