package rup.com.service;

import rup.com.modul.User;

public class UserServImpl implements UserServ {

	@Override
	public User createUser(User user) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public User getUserByID(int userID) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public User getUserByUsername(String username) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public User updateUser(int Id, User user) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public User deleteUser(int userID) {
		// TODO Auto-generated method stub
		return null;
	}

}
