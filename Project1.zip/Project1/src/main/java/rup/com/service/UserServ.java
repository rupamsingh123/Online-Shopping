package rup.com.service;

import rup.com.modul.User;

public interface UserServ {
	User createUser(User user);
    User getUserByID(int userID);

    // Method to retrieve a user by their username
    User getUserByUsername(String username);

    // Method to update an existing user
    User updateUser(int Id , User user);

    // Method to delete a user by their ID
    User deleteUser(int userID);

}
