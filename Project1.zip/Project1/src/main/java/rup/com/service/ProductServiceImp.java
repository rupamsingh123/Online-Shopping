package rup.com.service;

import rup.com.dao.ProductDaoImp;
import rup.com.modul.Product;

public class ProductServiceImp implements ProductService{
     ProductDaoImp pdao = new ProductDaoImp ();
	@Override
	public void createProduct(Product product) {
		// TODO Auto-generated method stub
		pdao.createProduct(product);
		
	}
	public void updateProduct(Product product) {
		pdao.updateProduct(product);
	}

}
