package rup.com.service;

import rup.com.modul.Product;

public interface ProductService {
	public void createProduct(Product product);
	public void updateProduct(Product product); 

}
