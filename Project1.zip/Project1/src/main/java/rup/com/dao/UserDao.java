package rup.com.dao;




import java.util.List;

import rup.com.modul.User;

public interface UserDao {
	    void createUser(User user);
	    List<User>getAllUser();
	    User getUserByID(int userID);

	    // Method to retrieve a user by their username
	    User getUserByUsername(String username);

	    // Method to update an existing user
	    User updateUser(int Id , User user);

	    // Method to delete a user by their ID
	    User deleteUser(int userID);
		List<User> displayAllUser();
	}



