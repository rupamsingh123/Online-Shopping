package rup.com.dao;

import java.io.Serializable;
import java.util.List;
import java.util.Scanner;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;

import rup.com.modul.Product;
import rup.com.util.HibernateUtil;

public class ProductDaoImp implements ProductDao {
	private static final Serializable Id = null;
	Scanner scanner=new Scanner(System.in);
	private SessionFactory sessionFactory;
	
	public ProductDaoImp() {
		this.sessionFactory=HibernateUtil.getSessionFactory();
	}


	@Override
	public void createProduct(Product product) {
		Transaction transaction=null;
		try {
		   Session session=sessionFactory.openSession();
		
			System.out.println("try");
			
			transaction=session.beginTransaction();
			System.out.println("Enter Name ");
			int id=1;
			String Name=scanner.nextLine();
			System.out.println("Enter description");
			String description=scanner.nextLine();
			System.out.println("Enter price ");
			double price=scanner.nextDouble();
			System.out.println("Enter stockquantity");
			int stockquantity=scanner.nextInt();
			Product cust=new Product(id,Name,description,price,stockquantity);
			
	        session.save(cust);
	        transaction.commit();
	        System.out.println("add product successfully");
	    /*} catch(Exception e) {
			
			session.save(product);
			transaction.commit();
			System.out.println("add product successfully");*/
		}
		catch(Exception e) {
			System.out.println("atri");
			  if (transaction != null) 
			  {
	             transaction.rollback();
			  }
			  e.printStackTrace();
		}
	    }
	
	

//Update Customer

	public void updateProduct(Product Product) {
		Transaction transaction = null;
	       try {
	    	   Session session = sessionFactory.openSession(); 
	           transaction = session.beginTransaction();
	           System.out.println("Enter Product ID");
	           int Id=scanner.nextInt();
	           scanner.nextLine();
	           Product cust=session.get(Product.class, Id);
	           
	           if(cust !=null) {
	        	   System.out.println("Enter updated Product name:");
	               String name = scanner.nextLine();
	               System.out.println("Enter updated description:");
	               String description=scanner.nextLine();
	               System.out.println("Enter updated price:");
	               double price = scanner.nextDouble();
	               System.out.println("Enter updated stockquantity:");
	               int stockquantity = scanner.nextInt();
	               
	               
	               cust.setName(name);
	               cust.setDescription(description);
	               cust.setPrice(price);
	               cust.setStockQuantity(stockquantity);
	               
	               session.update(cust);
	               transaction.commit();
	               System.out.println("Customer updated successfully.");
	           }
	           else {
	               System.out.println("Product with ID "+Id + " not found.");
	           }
	    }
	       catch (Exception e) {
	           if (transaction != null) {
	               transaction.rollback();
	           }
	           e.printStackTrace();
	       }
	}

}          

	/*@Override
	public void deleteProduct(Product product) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public List<Product> displayAllproduct() {
		// TODO Auto-generated method stub
		return null;
	}
	*/


