package rup.com.dao;


import java.util.List;
import java.util.Scanner;

//import javax.management.Query;
//import javax.persistence.TypedQuery;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;

import rup.com.modul.User;
import rup.com.util.HibernateUtil;

public class UserDaoImp implements UserDao {
	Scanner scanner=new Scanner(System.in);
	private SessionFactory sessionFactory;
	
	public UserDaoImp() {
		this.sessionFactory=HibernateUtil.getSessionFactory();
	}
	//insert customer
	@Override
	public void createUser(User user) {
		Transaction transaction=null;
		try(Session session=sessionFactory.openSession())
		{
			transaction=session.beginTransaction();
			System.out.println("Enter Name ");
			int id=1;
			String uName=scanner.nextLine();
			System.out.println("Enter Number ");
			String contactno=scanner.nextLine();
			System.out.println("Enter Email");
			String Email=scanner.nextLine();
			System.out.println("Enter Address");
			String Address=scanner.nextLine();
			System.out.println("Enter password");
			String password=scanner.nextLine();
			
			User use = new User(id,uName,contactno, password, Email,Address);
			
			session.save(use);
			transaction.commit();
			System.out.println("Account created successfully");
		}
		catch(Exception e) {
			if (transaction != null) 
			  {
	             transaction.rollback();
			  }
			e.printStackTrace();

		}
		
	}
	@Override
	public List<User> getAllUser() {
		
		return null;
	}
	@Override
	public User getUserByID(int userID) {
		
		return null;
	}
	@Override
	public User getUserByUsername(String username) {
		
		return null;
	}
	@Override
	public User updateUser(int Id, User user) {
		
		return null;
	}
	@Override
	public User deleteUser(int userID) {
		
		return null;
	}
	@Override
	public List<User> displayAllUser() {
		
		return null;
	}
	
	//Update Customer
	
	/*	public void updateUser(User user) {
			Transaction transaction = null;
		       try (Session session = sessionFactory.openSession()) {
		           transaction = session.beginTransaction();
		           System.out.println("Enter User ID");
		           long uId=scanner.nextLong();
		           scanner.nextLine();
		           User use=session.get(User.class, uId);
		           
		           if(use !=null) {
		        	   System.out.println("Enter updated User name:");
		               String name = scanner.nextLine();
		               System.out.println("Enter updated contactno:");
		               String number=scanner.nextLine();
		               System.out.println("Enter updated Email:");
		               String email = scanner.nextLine();
		               System.out.println("Enter updated Address:");
		               String address = scanner.nextLine();
		               use.setUsername(name);
		               use.setcontactno(contactno);
		               use.setEmail(email);
		               use.setAddress(address);
		               
		               session.update(use);
		               transaction.commit();
		               System.out.println("Customer updated successfully.");
		              
		           }
		           else {
		               System.out.println("User with ID "+uId + " not found.");
		           }
		    }
		       catch (Exception e) {
		           if (transaction != null) {
		               transaction.rollback();
		           }
		           e.printStackTrace();
		       }
		}
                    
		// Delete Customer 
		
		public void deleteStudent(User uesrId) {
			Transaction transaction = null;
		       try (Session session = sessionFactory.openSession()) {
		    	   System.out.println("Enter User Id");
		    	   long uid=scanner.nextLong();
		    	   User user=session.get(User.class, uid);
					session.beginTransaction();
					
					session.delete(user);//data will be deleted from DB
					session.getTransaction().commit();
					session.evict(user);//data will remove from session Cache
					System.out.println("Record deleted Successfully");
				
		       } catch (Exception e) {
		    	   System.out.println("Invalid User Id");
		           
		           }
                       
		          
		       }
		
		//retrieve data by id
		
		/*
		 * @Override
		 public Customer getCustomerById(Customer customer) {
			Transaction transaction = null;
		       try (Session session = sessionFactory.openSession()) {
		    	   transaction = session.beginTransaction();
		    	   
		    	   System.out.println("Enter CustomerID to Get Detail:");
		    	   long custId=scanner.nextLong();
		    	   Customer customer1=session.get(Customer.class, custId);
//		    	   return customer;
		      
		           return session.get(Customer.class, customer);
		       } catch (Exception e) {
		           e.printStackTrace();
		           return null;
		       }
		   }
                   */
	 //display All customer 
	/*@Override
	public List<User> displayAllUser() {
		try (Session session = SessionFactory.openSession()) {
			String hql="from User";  
			TypedQuery q=session.createQuery(hql);
			List<User> user=q.getResultList();
//			System.out.println(user);
			for (User user1 : user) {
                System.out.println("ID: " + user1.getUserId() + ", Name: " + user1.getUserName() +", Email: " + user1.getUserEmail() + ", Address: " + user1.getUserAddress()+"Number: " +user1.getUserNumber());
            }
			
			return user;
		
	           
	       } catch (Exception e) {
	    	   System.out.println("Display all error");
	           e.printStackTrace();
	       }
		return null;
	}
	@Override
	public List<User> getAllUser() {
		// TODO Auto-generated method stub
		return null;
	}
	@Override
	public User getUserByID(int userID) {
		// TODO Auto-generated method stub
		return null;
	}
	@Override
	public User getUserByUsername(String username) {
		// TODO Auto-generated method stub
		return null;
	}
	@Override
	public User updateUser(int Id, User user) {
		// TODO Auto-generated method stub
		return null;
	}
	@Override
	public User deleteUser(int userID) {
		// TODO Auto-generated method stub
		return null;
	}
*/
}



