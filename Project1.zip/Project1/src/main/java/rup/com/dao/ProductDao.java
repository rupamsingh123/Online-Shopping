package rup.com.dao;

//import java.util.List;

import rup.com.modul.Product;

public interface ProductDao {
	public void createProduct(Product product);
	public void updateProduct(Product product); 
	//public void deleteProduct(Product product);
	// List<Product> displayAllproduct();

}
